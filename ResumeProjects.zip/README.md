# Resume Projects

Two beginner-friendly projects that demonstrate different skills:

1. **ApplyTrack** — a responsive browser app for managing job applications. Open `ApplyTrack/index.html` directly.
2. **SalesLens** — a Python data dashboard. Follow `SalesLens/README.md` to install its packages and start it.

The data used by both demos is local or fictional. Suggested resume bullets are included in each project README. Personalize the projects and be ready to explain each feature before listing it on a resume.
