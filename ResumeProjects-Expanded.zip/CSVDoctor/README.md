# CSVDoctor

CSVDoctor is a command-line CSV cleanup and profiling tool written with Python's standard library. It trims cell whitespace, normalizes headers into unique `snake_case` names, converts common null markers into empty cells, removes fully blank rows and duplicate rows by default, pads short records, and writes a plain-text quality report.

## Run it

Install Python 3.10 or newer. From this folder, run:

```text
python csvdoctor.py sample_messy.csv
```

That creates `sample_messy.cleaned.csv` and `sample_messy.cleaned.report.txt`. Choose your own output and report locations with:

```text
python csvdoctor.py input.csv --output cleaned.csv --report quality-report.txt
```

Keep duplicate rows while still counting them in the report:

```text
python csvdoctor.py input.csv --keep-duplicates
```

CSVDoctor never overwrites its input file. For personal or confidential data, run it locally and do not upload those files to a public repository.

## Resume bullets

- Built a Python command-line data-cleaning tool that normalizes CSV headers, trims whitespace, handles missing values, and detects duplicate or malformed rows.
- Generated a human-readable quality report and cleaned CSV using only Python's standard library, with configurable output paths and safe input handling.
