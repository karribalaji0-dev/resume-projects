"""Clean common CSV formatting issues and write a plain-text quality report."""
import argparse
import csv
import re
import sys
from collections import Counter
from pathlib import Path

EMPTY_MARKERS = {"", "na", "n/a", "null", "none", "nan"}


def normalize_header(value, index, used):
    name = re.sub(r"[^a-zA-Z0-9]+", "_", value.strip().lower()).strip("_")
    if not name:
        name = f"column_{index + 1}"
    base, suffix = name, 2
    while name in used:
        name = f"{base}_{suffix}"
        suffix += 1
    used.add(name)
    return name


def clean_csv(source: Path, destination: Path, report_path: Path, keep_duplicates=False):
    if source.resolve() == destination.resolve():
        raise ValueError("Input and output must be different files; choose a new output path.")
    with source.open("r", encoding="utf-8-sig", newline="") as file:
        rows = list(csv.reader(file))
    if not rows:
        raise ValueError("The input file is empty.")
    raw_headers = rows[0]
    if not raw_headers:
        raise ValueError("The first row must contain column names.")

    data_rows = rows[1:]
    width = max([len(raw_headers), *(len(row) for row in data_rows)], default=len(raw_headers))
    used = set()
    headers = [normalize_header(h, i, used) for i, h in enumerate(raw_headers)]
    while len(headers) < width:
        headers.append(normalize_header(f"extra_column_{len(headers) - len(raw_headers) + 1}", len(headers), used))

    missing_counts = Counter()
    cleaned = []
    blank_rows = malformed_rows = duplicates = 0
    seen = set()
    for row in data_rows:
        if not any(cell.strip() for cell in row):
            blank_rows += 1
            continue
        if len(row) != len(raw_headers):
            malformed_rows += 1
        row = row[:width] + [""] * max(0, width - len(row))
        values = []
        for header, value in zip(headers, row):
            value = value.strip()
            if value.lower() in EMPTY_MARKERS:
                value = ""
                missing_counts[header] += 1
            values.append(value)
        fingerprint = tuple(values)
        if fingerprint in seen:
            duplicates += 1
            if not keep_duplicates:
                continue
        seen.add(fingerprint)
        cleaned.append(values)

    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(cleaned)

    report = [
        "CSVDoctor data quality report",
        "=" * 30,
        f"Input file: {source.name}",
        f"Output file: {destination.name}",
        f"Data rows read: {len(data_rows)}",
        f"Blank rows removed: {blank_rows}",
        f"Duplicate rows found: {duplicates}",
        f"Duplicate rows removed: {0 if keep_duplicates else duplicates}",
        f"Rows with a different number of cells than the header: {malformed_rows}",
        f"Rows written: {len(cleaned)}",
        "",
        "Normalized columns:",
        *[f"- {old.strip() or '(blank)'} -> {new}" for old, new in zip(raw_headers, headers)],
        "",
        "Blank values by column (after normalizing common null markers):",
        *([f"- {column}: {count}" for column, count in sorted(missing_counts.items())] or ["- No blank values found"]),
        "",
        "Notes:",
        "- Leading and trailing whitespace is removed from every cell.",
        "- Empty, NA, N/A, NULL, NONE, and NaN values are written as empty cells.",
        "- Rows with too few cells are padded; extra cells get extra_column_N headings.",
    ]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(report) + "\n", encoding="utf-8")
    return len(data_rows), len(cleaned), duplicates, blank_rows, malformed_rows


def main():
    parser = argparse.ArgumentParser(description="Trim, normalize, and summarize a CSV file.")
    parser.add_argument("input", type=Path, help="CSV file to clean")
    parser.add_argument("--output", type=Path, help="Cleaned CSV path (default: INPUT.cleaned.csv)")
    parser.add_argument("--report", type=Path, help="Report path (default: OUTPUT.report.txt)")
    parser.add_argument("--keep-duplicates", action="store_true", help="Report duplicate rows but keep them")
    args = parser.parse_args()
    output = args.output or args.input.with_name(f"{args.input.stem}.cleaned.csv")
    report = args.report or output.with_name(f"{output.stem}.report.txt")
    try:
        read_count, written_count, duplicate_count, blank_count, malformed_count = clean_csv(
            args.input, output, report, keep_duplicates=args.keep_duplicates
        )
    except (OSError, UnicodeError, csv.Error, ValueError) as error:
        print(f"CSVDoctor: {error}", file=sys.stderr)
        return 1
    print(f"Read {read_count} data rows; wrote {written_count} cleaned rows.")
    print(f"Found {duplicate_count} duplicates, {blank_count} blank rows, and {malformed_count} rows with a different cell count.")
    print(f"Cleaned CSV: {output}\nQuality report: {report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
