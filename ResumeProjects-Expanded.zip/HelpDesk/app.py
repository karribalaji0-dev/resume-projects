"""A beginner-friendly Flask and SQLite support ticket tracker."""
from pathlib import Path
import os
import sqlite3
from datetime import datetime

from flask import Flask, abort, flash, g, redirect, render_template, request, url_for
from flask_wtf import FlaskForm
from wtforms import SelectField, StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Length, Optional

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(exist_ok=True)
DATABASE = INSTANCE_DIR / "helpdesk.db"
STATUSES = ["Open", "In Progress", "Resolved"]
PRIORITIES = ["Low", "Medium", "High"]

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY", "local-demo-key-change-before-deployment")
app.config["DATABASE"] = str(DATABASE)


class TicketForm(FlaskForm):
    title = StringField("Subject", validators=[DataRequired(), Length(max=120)])
    requester = StringField("Requester name", validators=[DataRequired(), Length(max=80)])
    requester_email = StringField("Requester email (optional)", validators=[Optional(), Length(max=120)])
    priority = SelectField("Priority", choices=[(p, p) for p in PRIORITIES], default="Medium")
    status = SelectField("Status", choices=[(s, s) for s in STATUSES], default="Open")
    description = TextAreaField("Description", validators=[DataRequired(), Length(max=3000)])
    submit = SubmitField("Save ticket")


class DeleteForm(FlaskForm):
    submit = SubmitField("Delete ticket")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def initialize_database():
    db = sqlite3.connect(app.config["DATABASE"])
    db.execute("""CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        requester TEXT NOT NULL,
        requester_email TEXT NOT NULL DEFAULT '',
        priority TEXT NOT NULL CHECK(priority IN ('Low','Medium','High')),
        status TEXT NOT NULL CHECK(status IN ('Open','In Progress','Resolved')),
        description TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""")
    if db.execute("SELECT COUNT(*) FROM tickets").fetchone()[0] == 0:
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        samples = [
            ("Cannot reset password", "Avery Chen", "avery@example.test", "High", "Open", "The password reset email never arrives. Please check the account email settings.", now, now),
            ("Request access to reports", "Jordan Patel", "jordan@example.test", "Medium", "In Progress", "Please add access to the monthly reports workspace.", now, now),
            ("Update billing contact", "Morgan Lee", "", "Low", "Resolved", "The billing contact needs to be updated for next month.", now, now),
        ]
        db.executemany("""INSERT INTO tickets
            (title, requester, requester_email, priority, status, description, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", samples)
    db.commit()
    db.close()


def get_ticket(ticket_id):
    ticket = get_db().execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone()
    if ticket is None:
        abort(404)
    return ticket


@app.route("/")
def index():
    db = get_db()
    query = request.args.get("q", "").strip()
    status = request.args.get("status", "")
    if status not in STATUSES:
        status = ""
    conditions, params = [], []
    if query:
        conditions.append("(title LIKE ? OR requester LIKE ? OR description LIKE ?)")
        pattern = f"%{query}%"
        params.extend([pattern, pattern, pattern])
    if status:
        conditions.append("status = ?")
        params.append(status)
    where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    tickets = db.execute(f"SELECT * FROM tickets {where} ORDER BY updated_at DESC, id DESC", params).fetchall()
    counts = {row["status"]: row["amount"] for row in db.execute("SELECT status, COUNT(*) AS amount FROM tickets GROUP BY status")}
    return render_template("index.html", tickets=tickets, counts=counts, query=query, selected_status=status, statuses=STATUSES)


@app.route("/tickets/new", methods=["GET", "POST"])
def create_ticket():
    form = TicketForm()
    if form.validate_on_submit():
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        db = get_db()
        cursor = db.execute("""INSERT INTO tickets
            (title, requester, requester_email, priority, status, description, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (form.title.data.strip(), form.requester.data.strip(), (form.requester_email.data or "").strip(),
             form.priority.data, form.status.data, form.description.data.strip(), now, now))
        db.commit()
        flash("Ticket created.", "success")
        return redirect(url_for("ticket_detail", ticket_id=cursor.lastrowid))
    return render_template("ticket_form.html", form=form, page_title="New ticket")


@app.route("/tickets/<int:ticket_id>")
def ticket_detail(ticket_id):
    return render_template("ticket_detail.html", ticket=get_ticket(ticket_id), delete_form=DeleteForm())


@app.route("/tickets/<int:ticket_id>/edit", methods=["GET", "POST"])
def edit_ticket(ticket_id):
    ticket = get_ticket(ticket_id)
    form = TicketForm(obj=ticket)
    if form.validate_on_submit():
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        get_db().execute("""UPDATE tickets SET title=?, requester=?, requester_email=?, priority=?, status=?,
            description=?, updated_at=? WHERE id=?""",
            (form.title.data.strip(), form.requester.data.strip(), (form.requester_email.data or "").strip(),
             form.priority.data, form.status.data, form.description.data.strip(), now, ticket_id))
        get_db().commit()
        flash("Ticket updated.", "success")
        return redirect(url_for("ticket_detail", ticket_id=ticket_id))
    if request.method == "GET":
        form.title.data = ticket["title"]
        form.requester.data = ticket["requester"]
        form.requester_email.data = ticket["requester_email"]
        form.priority.data = ticket["priority"]
        form.status.data = ticket["status"]
        form.description.data = ticket["description"]
    return render_template("ticket_form.html", form=form, page_title=f"Edit ticket #{ticket_id}")


@app.route("/tickets/<int:ticket_id>/delete", methods=["POST"])
def delete_ticket(ticket_id):
    ticket = get_ticket(ticket_id)
    form = DeleteForm()
    if form.validate_on_submit():
        get_db().execute("DELETE FROM tickets WHERE id=?", (ticket_id,))
        get_db().commit()
        flash(f"Ticket #{ticket_id} deleted.", "success")
        return redirect(url_for("index"))
    return render_template("ticket_detail.html", ticket=ticket, delete_form=form), 400


initialize_database()

if __name__ == "__main__":
    app.run(debug=False)
