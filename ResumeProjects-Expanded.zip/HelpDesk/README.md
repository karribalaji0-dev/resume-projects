# HelpDesk Lite

A small support-ticket website built with Flask and SQLite. It demonstrates server-side forms, validation, database reads and writes, search, status filters, and reusable templates. Three fictional example tickets appear on the first run.

## Run it

Install Python 3.10 or newer. Open a terminal in this `HelpDesk` folder and run:

```text
python -m venv .venv
```

Activate it:

```text
# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate
```

Install and launch:

```text
python -m pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000` in your browser. The SQLite database is created in `instance/helpdesk.db`. Stop the server with Ctrl+C. To reset the demo tickets, stop the server and delete that database file; the app recreates it on the next start.

## Features

- Create, read, edit, and delete tickets
- Search subject, requester, or request details
- Filter by Open, In Progress, and Resolved status
- Track priority and updated time
- SQLite persistence and CSRF-protected forms

This is a local learning demo with no login or user permissions. Keep it on your computer; do not deploy it with real customer information without adding authentication and production security settings.

## Resume bullets

- Built a support-ticket web app using Flask, SQLite, and Jinja templates with ticket creation, editing, status tracking, and search.
- Added parameterized database queries, form validation, and CSRF protection while documenting local setup and sample data.
