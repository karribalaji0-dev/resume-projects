# Resume Projects

Four beginner-friendly projects that demonstrate different skills:

1. **ApplyTrack** — a responsive browser app for managing job applications. Open `ApplyTrack/index.html` directly.
2. **SalesLens** — a Python data dashboard. Follow `SalesLens/README.md` to install its packages and start it.
3. **HelpDesk Lite** — a Flask and SQLite support-ticket website. Follow `HelpDesk/README.md` to start it locally.
4. **CSVDoctor** — a Python command-line tool that cleans CSV files and creates a quality report. See `CSVDoctor/README.md`.

The data used by both demos is local or fictional. Suggested resume bullets are included in each project README. Personalize the projects and be ready to explain each feature before listing it on a resume.
